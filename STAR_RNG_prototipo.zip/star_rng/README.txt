STAR RNG - PROTOTIPO JOGAVEL

Abra index.html no navegador. No Android, para instalar como app, hospede a pasta em HTTPS e use o menu do Chrome > Adicionar à tela inicial.

Inclui sorteio pelas chances definidas, animação contínua de flutuação/brilho, rotação rápida durante o giro e efeito de impacto ao revelar a estrela, coleção salva no aparelho e ranking local pela raridade mais alta.

IMPORTANTE: Amigos, códigos e salas são apenas demonstrações locais nesta versão. O ZIP ainda não tem servidor, contas ou multiplayer real. Para jogar entre celulares será necessário conectar um backend online (Firebase ou Supabase).

Chances: Comum 50%, Incomum 25%, Raro 12%, Epic 7%, Lendário 3%, Mítico 1,5%, Divino 0,8%, Cosmic 0,4%, Eternal 0,2%, Secreto 0,1%.
